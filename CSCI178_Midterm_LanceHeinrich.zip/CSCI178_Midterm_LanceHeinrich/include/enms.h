#ifndef ENMS_H
#define ENMS_H


class enms
{
    public:
        enms();
        virtual ~enms();

    protected:

    private:
};

#endif // ENMS_H
