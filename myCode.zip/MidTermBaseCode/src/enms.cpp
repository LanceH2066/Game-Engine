#include "enms.h"

enms::enms()
{
    //ctor
}

enms::~enms()
{
    //dtor
}
